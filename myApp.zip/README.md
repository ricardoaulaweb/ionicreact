# Instalar o Ionic CLI para executar o servidor

> npm install -g @ionic/cli

---

# Instalar dependencias do projeto

> npm install

---

# Iniciar servidor dev

> ionic serve
