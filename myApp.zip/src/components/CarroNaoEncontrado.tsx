import { IonContent, IonPage } from "@ionic/react";
import React from "react";

export default () => (
  <IonPage>
    <IonContent fullscreen>
      <h1>Carro não encontrado</h1>
    </IonContent>
  </IonPage>
);
