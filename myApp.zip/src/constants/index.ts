export const defaultAvatar =
  "https://icon-library.com/images/car-icon-white/car-icon-white-1.jpg";
