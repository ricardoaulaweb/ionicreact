export enum TipoCarro {
  SEDAN = "Sedan",
  SUV = "SUV",
  PICK_UP = "Pickup",
  COUPE = "Coupe",
  HATCHBACK = "Hatchback",
}
